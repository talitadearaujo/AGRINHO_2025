let player;
let itemsCampo = [];
let itemsCidade = [];
let obstacles = [];
let gameState = "campo";
let collectedItems = 0;
let maxItems = 5;

function setup() {
  createCanvas(600, 400);
  
  player = new Player();
  
  // Criar itens no campo
  for (let i = 0; i < maxItems; i++) {
    itemsCampo.push(new Item(random(100, 300), random(50, 350), "campo"));
  }
  
  // Criar obstáculos
  for (let i = 0; i < 3; i++) {
    obstacles.push(new Obstacle(random(200, 400), random(100, 300)));
  }
  
}

function draw() {
  background(200);
  
  if (gameState === "campo") {
    drawCampo();
    player.move();
    player.show();
    player.collectItem();

    // Mostrar itens do campo
    for (let item of itemsCampo) {
      item.show();
    }
    
    // Mostrar obstáculos
    for (let obs of obstacles) {
      obs.show();
      obs.move();
    }
    
    // Verificar se o jogador coletou todos os itens
    if (collectedItems >= maxItems) {
      gameState = "cidade"; // Mudar para a cidade
    }
    
  } else if (gameState === "cidade") {
    drawCidade();
    player.move();
    player.show();

    // Exibir itens coletados na cidade
    for (let item of itemsCidade) {
      item.show();
    }

    // Exibe mensagem de chegada na festa
    textSize(32);
    fill(255);
    text("Você chegou na festa!", 150, 100);
    
    // Tocar música ou sons celebrando a conexão
    playCelebrationSound();
  }
}

function drawCampo() {
  background(100, 255, 100); // Cor de fundo do campo
  
  // Desenha o cenário do campo
  fill(255, 165, 0);
  rect(0, 300, width, 100); // Solo do campo
  textSize(24);
  fill(0);
  text("Campo - Coleta itens para a festa!", 150, 50);
}

function drawCidade() {
  background(150, 150, 255); // Cor de fundo da cidade

  // Desenha o cenário da cidade
  fill(200);
  rect(0, height - 50, width, 50); // Rua da cidade
  fill(255, 0, 0);
  for (let i = 0; i < 5; i++) {
    rect(100 * i, height - 150, 80, 100); // Prédios da cidade
  }

  textSize(24);
  fill(0);
  text("Cidade - Organize a festa com os itens!", 150, 50);
}

// Função para tocar música ou som
function playCelebrationSound() {
  if (!sounds.isPlaying()) {
    sounds.play(); // Toca som de celebração
  }
}

// Classe do jogador
class Player {
  constructor() {
    this.x = 100;
    this.y = 250;
    this.width = 40;
    this.height = 40;
    this.speed = 4;
  }
  
  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }
  }

  collectItem() {
    if (gameState === "campo") {
      for (let i = itemsCampo.length - 1; i >= 0; i--) {
        let item = itemsCampo[i];
        if (dist(this.x, this.y, item.x, item.y) < 30) {
          collectedItems++; // Aumenta a contagem de itens coletados
          itemsCidade.push(item); // Mover item para a cidade
          itemsCampo.splice(i, 1); // Remove o item do campo
        }
      }
    }
  }

  show() {
    fill(0, 255, 0);
    rect(this.x, this.y, this.width, this.height);
  }
}

// Classe dos itens
class Item {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.size = 20;
    this.type = type; // Campo ou cidade
  }

  show() {
    fill(255, 165, 0);
    ellipse(this.x, this.y, this.size, this.size);
  }
}

// Classe dos obstáculos
class Obstacle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 30;
  }

  show() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.size, this.size);
  }

  move() {
    this.x -= 2; // Obstáculo se move para a esquerda
  }
}
